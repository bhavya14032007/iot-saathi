import { ProjectIdea } from './types';

export const PROJECT_IDEAS: ProjectIdea[] = [
  {
    id: '1',
    title: 'Smart Home Lighting',
    description: 'Control lights using a smartphone or motion sensor.',
    difficulty: 'Beginner',
    category: 'Home Automation'
  },
  {
    id: '2',
    title: 'Weather Station',
    description: 'Monitor temperature, humidity, and pressure with an LCD display.',
    difficulty: 'Intermediate',
    category: 'Environment'
  },
  {
    id: '3',
    title: 'Plant Watering System',
    description: 'Automatically water your plants when the soil is dry.',
    difficulty: 'Beginner',
    category: 'Agriculture'
  },
  {
    id: '4',
    title: 'Fingerprint Door Lock',
    description: 'Secure your room with a fingerprint scanner and solenoid lock.',
    difficulty: 'Advanced',
    category: 'Security'
  },
  {
    id: '5',
    title: 'Obstacle Avoiding Robot',
    description: 'A robot that navigates around objects using ultrasonic sensors.',
    difficulty: 'Intermediate',
    category: 'Robotics'
  },
  {
    id: '6',
    title: 'RFID Attendance System',
    description: 'Track attendance using RFID tags and an SD card module.',
    difficulty: 'Intermediate',
    category: 'Utility'
  }
];
