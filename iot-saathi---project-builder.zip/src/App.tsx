import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Cpu, Zap, Package, Search, Sparkles, ChevronRight, Loader2, Wrench, X } from "lucide-react";
import { PROJECT_IDEAS } from "./constants";
import { ProjectIdea, ProjectDetails } from "./types";
import { ProjectCard } from "./components/ProjectCard";
import { CodeViewer } from "./components/CodeViewer";
import { DiagramViewer } from "./components/DiagramViewer";
import { generateProjectDetails, suggestProjectsByComponents } from "./services/geminiService";

export default function App() {
  const [selectedProject, setSelectedProject] = useState<ProjectIdea | null>(null);
  const [details, setDetails] = useState<ProjectDetails | null>(null);
  const [loading, setLoading] = useState(false);
  const [suggesting, setSuggesting] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [userComponents, setUserComponents] = useState("");
  const [suggestedProjects, setSuggestedProjects] = useState<ProjectIdea[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  const filteredProjects = PROJECT_IDEAS.filter((p) =>
    p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleProjectSelect = async (project: ProjectIdea) => {
    if (selectedProject?.id === project.id) return;
    
    setSelectedProject(project);
    setLoading(true);
    setDetails(null);
    
    try {
      const result = await generateProjectDetails(project.title, project.description);
      setDetails(result);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleSuggestProjects = async () => {
    if (!userComponents.trim()) return;
    
    setSuggesting(true);
    setShowSuggestions(true);
    try {
      const suggestions = await suggestProjectsByComponents(userComponents);
      setSuggestedProjects(suggestions);
    } catch (error) {
      console.error(error);
    } finally {
      setSuggesting(false);
    }
  };

  const clearSuggestions = () => {
    setShowSuggestions(false);
    setSuggestedProjects([]);
    setUserComponents("");
  };

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-900 font-sans">
      {/* Header */}
      <header className="border-b border-zinc-200 bg-white sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-zinc-900 rounded-lg flex items-center justify-center">
              <Cpu className="text-white" size={18} />
            </div>
            <h1 className="font-bold text-xl tracking-tight">IoT Saathi <span className="text-zinc-400 font-normal">Build</span></h1>
          </div>
          
          <div className="relative hidden md:flex items-center gap-4 flex-1 max-w-2xl mx-8">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
              <input
                type="text"
                placeholder="Search projects..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-zinc-100 border-transparent focus:bg-white focus:border-zinc-300 rounded-full text-sm transition-all outline-none"
              />
            </div>
            
            <div className="relative flex-[1.5] flex items-center gap-2">
              <div className="relative flex-1">
                <Wrench className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
                <input
                  type="text"
                  placeholder="Enter components you have (e.g. Arduino, LED, PIR)..."
                  value={userComponents}
                  onChange={(e) => setUserComponents(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSuggestProjects()}
                  className="w-full pl-10 pr-4 py-2 bg-zinc-100 border-transparent focus:bg-white focus:border-zinc-300 rounded-full text-sm transition-all outline-none"
                />
              </div>
              <button 
                onClick={handleSuggestProjects}
                disabled={suggesting || !userComponents.trim()}
                className="px-4 py-2 bg-zinc-900 text-white rounded-full text-xs font-semibold hover:bg-zinc-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {suggesting ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
                Suggest
              </button>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button className="text-xs font-semibold text-zinc-500 hover:text-zinc-900 transition-colors uppercase tracking-widest">
              Components
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Sidebar - Project List */}
          <div className="lg:col-span-4 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold uppercase tracking-widest text-zinc-400">
                {showSuggestions ? "AI Suggestions" : "Project Ideas"}
              </h2>
              <div className="flex items-center gap-2">
                {showSuggestions && (
                  <button 
                    onClick={clearSuggestions}
                    className="text-[10px] text-rose-500 hover:text-rose-600 font-bold uppercase flex items-center gap-1"
                  >
                    <X size={10} /> Clear
                  </button>
                )}
                <span className="text-[10px] bg-zinc-200 px-2 py-0.5 rounded-full font-mono">
                  {showSuggestions ? suggestedProjects.length : filteredProjects.length} Projects
                </span>
              </div>
            </div>
            
            <div className="space-y-4 max-h-[calc(100vh-200px)] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-zinc-200">
              {suggesting ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-32 bg-zinc-100 animate-pulse rounded-xl border border-zinc-200" />
                  ))}
                </div>
              ) : (
                <>
                  {(showSuggestions ? suggestedProjects : filteredProjects).map((project) => (
                    <ProjectCard
                      key={project.id}
                      project={project}
                      isSelected={selectedProject?.id === project.id}
                      onClick={() => handleProjectSelect(project)}
                    />
                  ))}
                  {showSuggestions && suggestedProjects.length === 0 && !suggesting && (
                    <div className="text-center py-12 px-4 bg-zinc-100 rounded-xl border border-dashed border-zinc-300">
                      <p className="text-sm text-zinc-500">No suggestions found. Try adding more components.</p>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>

          {/* Main Content - Details */}
          <div className="lg:col-span-8">
            <AnimatePresence mode="wait">
              {!selectedProject ? (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="h-full flex flex-col items-center justify-center text-center p-12 bg-white rounded-3xl border border-dashed border-zinc-300"
                >
                  <div className="w-16 h-16 bg-zinc-100 rounded-2xl flex items-center justify-center mb-6">
                    <Sparkles className="text-zinc-400" size={32} />
                  </div>
                  <h3 className="text-2xl font-bold mb-2">Select a Project</h3>
                  <p className="text-zinc-500 max-w-md">
                    Choose a project from the list or enter your components above to get AI-powered suggestions.
                  </p>
                </motion.div>
              ) : (
                <motion.div
                  key={selectedProject.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-8"
                >
                  {/* Project Header */}
                  <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm">
                    <div className="flex items-center gap-2 text-zinc-400 text-xs mb-4">
                      <span>Projects</span>
                      <ChevronRight size={12} />
                      <span className="text-zinc-900 font-medium">{selectedProject.title}</span>
                    </div>
                    <h2 className="text-4xl font-bold mb-4 tracking-tight">{selectedProject.title}</h2>
                    <p className="text-zinc-600 text-lg leading-relaxed">{selectedProject.description}</p>
                  </div>

                  {loading ? (
                    <div className="flex flex-col items-center justify-center py-20 bg-white rounded-3xl border border-zinc-200">
                      <Loader2 className="animate-spin text-zinc-900 mb-4" size={40} />
                      <p className="text-zinc-500 font-medium">Generating project details using Gemini...</p>
                    </div>
                  ) : details ? (
                    <div className="space-y-8">
                      {/* Components Section */}
                      <section className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm">
                        <div className="flex items-center gap-2 mb-6">
                          <Package className="text-zinc-900" size={20} />
                          <h3 className="text-xl font-bold">Components Required</h3>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {details.componentsNeeded.map((item, i) => (
                            <div key={i} className="flex items-center gap-3 p-3 bg-zinc-50 rounded-xl border border-zinc-100">
                              <div className="w-2 h-2 rounded-full bg-zinc-300" />
                              <span className="text-sm font-medium text-zinc-700">{item}</span>
                            </div>
                          ))}
                        </div>
                      </section>

                      {/* Connection Diagram Section */}
                      <section className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm">
                        <div className="flex items-center gap-2 mb-6">
                          <Zap className="text-zinc-900" size={20} />
                          <h3 className="text-xl font-bold">Connection Diagram</h3>
                        </div>
                        <DiagramViewer content={details.connectionDiagram} />
                      </section>

                      {/* Code Section */}
                      <section className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm">
                        <div className="flex items-center gap-2 mb-6">
                          <Cpu className="text-zinc-900" size={20} />
                          <h3 className="text-xl font-bold">Arduino Code</h3>
                        </div>
                        <CodeViewer code={details.arduinoCode} />
                      </section>
                    </div>
                  ) : null}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-200 bg-white py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-zinc-900 rounded flex items-center justify-center">
              <Cpu className="text-white" size={14} />
            </div>
            <span className="font-bold">IoT Saathi</span>
          </div>
          <p className="text-zinc-400 text-sm">© 2026 IoT Saathi. Built with Gemini AI.</p>
          <div className="flex gap-6">
            <a href="#" className="text-zinc-400 hover:text-zinc-900 text-sm transition-colors">Privacy</a>
            <a href="#" className="text-zinc-400 hover:text-zinc-900 text-sm transition-colors">Terms</a>
            <a href="#" className="text-zinc-400 hover:text-zinc-900 text-sm transition-colors">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
