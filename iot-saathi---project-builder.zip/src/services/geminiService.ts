import { GoogleGenAI, Type } from "@google/genai";
import { ProjectDetails, ProjectIdea } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function generateProjectDetails(projectTitle: string, projectDescription: string): Promise<ProjectDetails> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Generate Arduino code and connection details for the project: "${projectTitle}". 
    Description: ${projectDescription}.
    
    Provide:
    1. A complete, well-commented Arduino code.
    2. A clear, step-by-step connection diagram description (which pin goes where).
    3. A list of electronic components required.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          arduinoCode: {
            type: Type.STRING,
            description: "The complete Arduino code for the project.",
          },
          connectionDiagram: {
            type: Type.STRING,
            description: "A detailed markdown description of the wiring connections.",
          },
          componentsNeeded: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "List of components needed for the project.",
          },
        },
        required: ["arduinoCode", "connectionDiagram", "componentsNeeded"],
      },
    },
  });

  try {
    return JSON.parse(response.text || "{}") as ProjectDetails;
  } catch (error) {
    console.error("Failed to parse Gemini response:", error);
    throw new Error("Failed to generate project details.");
  }
}

export async function suggestProjectsByComponents(components: string): Promise<ProjectIdea[]> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `I have the following electronic components: ${components}. 
    Suggest 3-5 interesting IoT or electronics project ideas I can build with these. 
    Return a list of projects with titles, descriptions, difficulty levels (Beginner, Intermediate, Advanced), and categories.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            difficulty: { type: Type.STRING, enum: ["Beginner", "Intermediate", "Advanced"] },
            category: { type: Type.STRING },
          },
          required: ["id", "title", "description", "difficulty", "category"],
        },
      },
    },
  });

  try {
    return JSON.parse(response.text || "[]") as ProjectIdea[];
  } catch (error) {
    console.error("Failed to parse Gemini suggestions:", error);
    return [];
  }
}
