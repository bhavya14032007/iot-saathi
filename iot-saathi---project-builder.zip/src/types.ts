export interface ProjectIdea {
  id: string;
  title: string;
  description: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  category: string;
}

export interface ProjectDetails {
  arduinoCode: string;
  connectionDiagram: string;
  componentsNeeded: string[];
}
