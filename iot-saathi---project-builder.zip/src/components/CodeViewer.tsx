import Markdown from "react-markdown";
import { Copy, Check } from "lucide-react";
import { useState } from "react";

interface CodeViewerProps {
  code: string;
}

export function CodeViewer({ code }: CodeViewerProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="relative group rounded-xl overflow-hidden border border-zinc-800 bg-zinc-950">
      <div className="flex items-center justify-between px-4 py-2 bg-zinc-900 border-bottom border-zinc-800">
        <span className="text-[10px] font-mono text-zinc-400 uppercase tracking-widest">arduino_code.ino</span>
        <button
          onClick={handleCopy}
          className="p-1.5 rounded-md hover:bg-zinc-800 text-zinc-400 transition-colors"
          title="Copy code"
        >
          {copied ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
        </button>
      </div>
      <div className="p-4 overflow-x-auto max-h-[500px] scrollbar-thin scrollbar-thumb-zinc-800">
        <pre className="text-xs font-mono text-zinc-300 leading-relaxed">
          <code>{code}</code>
        </pre>
      </div>
    </div>
  );
}
