import { ProjectIdea } from "../types";
import { Cpu, Zap, Layers } from "lucide-react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface ProjectCardProps {
  project: ProjectIdea;
  isSelected: boolean;
  onClick: () => void;
}

export function ProjectCard({ project, isSelected, onClick }: ProjectCardProps) {
  const difficultyColor = {
    Beginner: "text-emerald-500 bg-emerald-500/10 border-emerald-500/20",
    Intermediate: "text-amber-500 bg-amber-500/10 border-amber-500/20",
    Advanced: "text-rose-500 bg-rose-500/10 border-rose-500/20",
  }[project.difficulty];

  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full text-left p-4 rounded-xl border transition-all duration-200 group",
        isSelected
          ? "bg-zinc-900 border-zinc-700 shadow-lg"
          : "bg-white border-zinc-200 hover:border-zinc-400 hover:shadow-md"
      )}
    >
      <div className="flex justify-between items-start mb-2">
        <span className={cn("px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border", difficultyColor)}>
          {project.difficulty}
        </span>
        <span className="text-[10px] text-zinc-400 font-mono uppercase">{project.category}</span>
      </div>
      <h3 className={cn("text-lg font-semibold mb-1", isSelected ? "text-white" : "text-zinc-900")}>
        {project.title}
      </h3>
      <p className={cn("text-sm line-clamp-2", isSelected ? "text-zinc-400" : "text-zinc-500")}>
        {project.description}
      </p>
      
      <div className="mt-4 flex items-center gap-3 opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="flex items-center gap-1 text-[10px] text-zinc-400">
          <Cpu size={12} />
          <span>Code</span>
        </div>
        <div className="flex items-center gap-1 text-[10px] text-zinc-400">
          <Zap size={12} />
          <span>Wiring</span>
        </div>
        <div className="flex items-center gap-1 text-[10px] text-zinc-400">
          <Layers size={12} />
          <span>Parts</span>
        </div>
      </div>
    </button>
  );
}
