import Markdown from "react-markdown";

interface DiagramViewerProps {
  content: string;
}

export function DiagramViewer({ content }: DiagramViewerProps) {
  return (
    <div className="prose prose-invert prose-sm max-w-none">
      <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-6 text-zinc-900">
        <Markdown
          components={{
            h1: ({ children }) => <h1 className="text-xl font-bold mb-4 text-zinc-900">{children}</h1>,
            h2: ({ children }) => <h2 className="text-lg font-semibold mt-6 mb-3 text-zinc-800">{children}</h2>,
            h3: ({ children }) => <h3 className="text-md font-semibold mt-4 mb-2 text-zinc-700">{children}</h3>,
            ul: ({ children }) => <ul className="list-disc pl-5 space-y-2 mb-4">{children}</ul>,
            ol: ({ children }) => <ol className="list-decimal pl-5 space-y-2 mb-4">{children}</ol>,
            li: ({ children }) => <li className="text-zinc-600">{children}</li>,
            table: ({ children }) => (
              <div className="overflow-x-auto my-4">
                <table className="min-w-full divide-y divide-zinc-200 border border-zinc-200 rounded-lg overflow-hidden">
                  {children}
                </table>
              </div>
            ),
            thead: ({ children }) => <thead className="bg-zinc-100">{children}</thead>,
            th: ({ children }) => <th className="px-4 py-2 text-left text-xs font-bold text-zinc-500 uppercase tracking-wider">{children}</th>,
            td: ({ children }) => <td className="px-4 py-2 text-sm text-zinc-600 border-t border-zinc-100">{children}</td>,
            code: ({ children }) => <code className="bg-zinc-200 px-1 rounded text-zinc-800 font-mono text-xs">{children}</code>,
          }}
        >
          {content}
        </Markdown>
      </div>
    </div>
  );
}
